// Extension API configuration
// Update this URL to your deployed backend
const API_URL = 'https://cognify-gxaa.onrender.com/api';

// For production deployment:
// 1. Replace the URL above with your backend URL (e.g., 'https://cognify-api.onrender.com/api')
// 2. Reload the extension in chrome://extensions

export default API_URL;
